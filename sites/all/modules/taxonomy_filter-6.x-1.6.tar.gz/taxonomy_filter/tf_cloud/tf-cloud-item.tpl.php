<?php
// $Id$
?>
<span<?php if (isset($class)) { print ' class="'. $class .'"'; } ?>>
<?php if (isset($pre_link)) { print $pre_link; } ?><?php if (isset($link)) { print $link; } ?><?php if (isset($post_link)) { print $post_link; } ?>
</span>
