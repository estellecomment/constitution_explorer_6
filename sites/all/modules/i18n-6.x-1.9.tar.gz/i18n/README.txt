
README.txt
==========

********************************************************************
This is i18n package 6.x, and works with Drupal 6.x
********************************************************************
WARNING: DO READ THE INSTALL FILE AND the ON-LINE HANDBOOK
********************************************************************

This is a collection of modules providing multilingual features.
These modules will build onto Drupal 6 core features enabling a full multilingual site

Up to date documentation will be kept on-line at http://drupal.org/node/133977

SimpleTest:
-----------
Tests for this module will run on SimpleTest 6.x-2.8 (old version).
About this see http://drupal.org/node/584596

Additional Support
=================
For support, please create a support request for this module's project:
  http://drupal.org/project/i18n

Support questions by email to the module maintainer will be simply ignored. Use the issue tracker.

====================================================================
Jose A. Reyero, drupal at reyero dot net, http://www.reyero.net
