IMAGE MODULE
-------------

Image.module is responsible for the creation & maintenance of "image
nodes" that can be used for several purposes - such as embedding in
other nodes, or used on their own to display photographs, screenshots or
diagrams. 

Author:
James Walker <james@lullabot.com>
