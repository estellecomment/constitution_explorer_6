/*
 * Copyright 2008 ThinkLeft (thinkleft.com.au)
 * Copyright 2008 ProsePoint (www.prosepoint.org)
 * Copyright Arun Kale (http://themasterplan.in)
 */

This is a port of the Wordpress theme The Morning After to Drupal/ProsePoint, developed as a subtheme of Zen. 

The original graphic design and Wordpress theme were created by Arun Kale (http://themasterplan.in). It's home page is http://code.google.com/p/the-morning-after.

This theme port is copyrighted as above, but it is licensed by the GNU General Public License 2. 

NOTE: You must install the Zen theme first! See http://drupal.org/project/zen. 

The Morning After was developed using zen-6.x-1.0-beta2.tar.gz, so it is known to work with this version of Zen. Future versions of Zen should also work. 

In case you're wondering about ProsePoint, it's a Drupal distribution targeted at creating online newspapers sites. Tma was ported to be the base theme for ProsePoint. See www.prosepoint.org for more information. 



