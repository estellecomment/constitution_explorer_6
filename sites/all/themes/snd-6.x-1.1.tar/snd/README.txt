$id$

CONTENTS

1. License Notice
2. Credits & Contact
3. Installation Instructions
4. Removal of "Theme by Review Critical" in Footer.
5. TODO

--------------------------------------------------------------------------------

1. LICENSE NOTICE

  Copyright 2009 ReviewCritical.com

  This file is part of Social Networking Dream.

  Social Networking Dream is free software: you can redistribute it and/or modify it under 
  the terms of the GNU General Public License as published by the Free Software 
  Foundation, either version 3 of the License, or (at your option) any later 
  version.

  Social Networking Dream is distributed in the hope that it will be useful, but WITHOUT 
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more 
  details.

  You should have received a copy of the GNU General Public License along with 
  Social Networking Dream.  If not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------------------

2. CREDITS & CONTACT

  Theme created by Review Critical
  www.ReviewCritical.com

  Please submit any problems to drupal.org project page

--------------------------------------------------------------------------------

3. INSTALLATION INSTRUCTIONS

  To install this theme simply place the entire snd folder in your
  themes directory, located at your_drupal_site/sites/all/themes .  Then log into your
  drupal site with any account that has sufficient privileges to administrate
  themes and head to the theme configuration page by Administer->Site Building->
  Themes. Tick the "Enabled" check box next to Social Networking Dream to enable it and if
  you wish to make it your default theme, select the "Default" radio box in line
  with Social Networking Dream as well.

--------------------------------------------------------------------------------

5. TODO
Copy and paste dropdown menu css for nice menus module
Integration with color ng module